﻿#include <BEMod.h>

struct _主窗口 : 窗口
{
	
#pragma region 组件成员

#pragma endregion
	void 载入(窗口* 父窗 = 0, bool 模态 = 0);
	void 完毕(bool 模态 = 0);
} 主窗口;