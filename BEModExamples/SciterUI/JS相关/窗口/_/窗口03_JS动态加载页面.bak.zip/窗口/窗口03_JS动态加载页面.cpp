﻿#include <BEMod.h>

struct _窗口03_JS动态加载页面 : 窗口
{
	
#pragma region 组件成员
	struct _st :SciterUI {
	} st;
#pragma endregion
	void 载入(窗口* 父窗 = 0, bool 模态 = 0);
	void 完毕(bool 模态 = 0);
} 窗口03_JS动态加载页面;