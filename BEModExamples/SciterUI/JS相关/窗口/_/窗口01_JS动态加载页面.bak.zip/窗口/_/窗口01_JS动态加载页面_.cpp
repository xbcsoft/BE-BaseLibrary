﻿#include "../窗口01_JS动态加载页面.h"

void _窗口01_JS动态加载页面::载入(窗口* 父窗, bool 模态)
{
	if (窗口句柄)return;
	窗口01_JS动态加载页面.创建({}, 父窗, 模态);

	
	
	窗口::完毕(模态);
}

void _窗口01_JS动态加载页面::完毕(bool 模态)
{
	SciterUI::参数 cs;
	cs.文件_html = "index.html";
	st.创建(cs, this);
	窗口::完毕(模态);
}
