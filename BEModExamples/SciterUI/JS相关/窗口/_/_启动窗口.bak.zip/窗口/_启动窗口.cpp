﻿#include <BEMod.h>

struct __启动窗口 : 窗口
{
	SciterCtx ctx;

	void 事件_创建完毕()
	{
		ctx = this->st.取根Ctx();
		//对象的引用();
		//数组的引用();
		多参使用();
	}

	void 多参使用()
	{//虽然默认情况下只有一个参数（为了设计简洁，若希望多参可以投入对象）
		

	}

	void 数组的引用()
	{
		调试输出("\n\n——————测试用例【数组的引用】——————");
		// 1. 原生 C++ 数组 (T_ARRAY) 示例
		SciterObj arr1;
		arr1.加入成员("苹果");
		arr1.加入成员("香蕉");
		arr1.加入成员(100);

		调试输出("【arr1 成员数】=", arr1.取数组成员数());
		调试输出("【arr1 内容】", arr1);
		调试输出("【arr1[1]】", (StrW)arr1[1]);

		arr1.置成员(1, "鸭梨");
		调试输出("【修改 arr1[1] 后】 = ", arr1);

		// 2. JS 堆原生 Array (T_OBJECT) 示例
		SciterObj arr2;
		ctx.执行JS脚本("[]", arr2);
		arr2.加入成员("红楼梦");
		arr2.加入成员("西游记");
		调试输出("【arr2 成员数】=", arr2.取数组成员数());
		调试输出("【arr2 内容】", arr2);

		arr2.置成员(0, "三国演义");
		调试输出("【修改 arr2[0] 后】 = ", arr2);

		ctx.执行JS脚本(
			"function modifyArray(arr) {"
			"   arr[0] = '水浒传';"
			"   arr.push('封神演义');"
			"}", nil);

		ctx.调用JS函数("modifyArray", arr1);
		调试输出("【T_ARRAY版】经JS修改后 arr1 = ", arr1);

		ctx.调用JS函数("modifyArray", arr2);
		调试输出("【T_OBJECT_Array版】经JS修改后 arr2 = ", arr2);
	}

	void 对象的引用()
	{
		调试输出("\n\n——————测试用例【对象的引用】——————");
		SciterObj o1;
		o1.置属性("age", 17);
		o1.置属性("addr.city", "广州");
		o1.置属性("addr.street", "中山路");
		调试输出(o1);

		SciterObj o2 = o1.取属性("addr");
		调试输出(o2);
		o2.置属性("city", "深圳");
		调试输出(o2, o1);
		//这个之所以能改主要是内部做了回写父节点兜底，但它不能用于JS交互的引用！
		
		// 在 JS 引擎中注入一个修改对象的函数
		ctx.执行JS脚本(
			"function modifyPerson(p) {"
			"   p.age = 30;"
			"   p.addr.city = '上海';"
			"}", nil);

		ctx.调用JS函数("modifyPerson", o1);
		调试输出("【T_MAP版_经JS修改后】 o1 = ", o1);
		
		//————————————————————————————

		调试输出("\n接下来测T_OBJECT版：", o1);
		SciterObj o3(ctx);   //使用ctx创建的JS对象就是T_OBJECT版
		o3.置属性("age", 17);
		o3.置属性("addr.city", "广州");
		o3.置属性("addr.street", "中山路");
		调试输出(o3);

		SciterObj o4 = o3.取属性("addr");
		调试输出(o4);
		o4.置属性("city", "深圳"); //这个改写是真引用
		调试输出(o3, o4);

		ctx.调用JS函数("modifyPerson", o3);
		调试输出("【T_OBJECT版_经JS修改后】 o3 = ", o3);
	}

#pragma region 组件成员
	struct _st :SciterUI {
	} st;
#pragma endregion
	void 载入(窗口* 父窗 = 0, bool 模态 = 0);
	void 完毕(bool 模态 = 0);
} _启动窗口;
