﻿//#include <BEMod.h>
#include "../窗口3.h"

void _窗口3::载入(窗口* 父窗, bool 模态)
{
	if (窗口句柄)return;
	窗口::参数 cs;
	cs.子控件焦点导航 = true;
	cs.边框 = 窗口边框::普通可调边框;
	窗口::创建(cs, 父窗,模态);

	按钮1.创建(按钮::参数(200, 100, 50, 30), this);

	选择夹::参数 a(10, 10, 200, 100);
	选择夹1.创建(a, this);
	图片组 tpz;
	tpz.创建(32, 32);
	tpz.添加图片文件(LR"(D:\360YunPan\易语言程序\小工具\py去背景色\icons\超级链接框.bmp)", IMAGE_BITMAP, false);

	选择夹1.置图片组(tpz);

	选择夹1.插入子夹(_T("测试"), nil, 0);
	选择夹1.插入子夹(_T("asd"));

	按钮* an = new 按钮;
	an->创建(按钮::参数(10, 10, 50, 30, false), 选择夹1);
	选择夹1.子夹添加组件(0, *an);

	_窗口3::完毕(模态);
}


void _窗口3::完毕(bool 模态)
{
	// --- 骚操作：全局虚表劫持 ---
	// 目标：黑掉“按钮”类的虚表，让所有该类的实例点一下都弹窗
	
	// 1. 获取按钮类的虚表地址
	// 我们直接拿 this->按钮1 的虚表
	void** vtable = *(void***)&按钮1;

	// 2. 探测“事件_被单击”的索引
	// 我们创建一个重写了该函数的临时对象，对比虚表差异
	struct 探测器 : 按钮 { virtual void 事件_被单击() override {} };
	探测器 obj;
	void** 探测虚表 = *(void***)&obj;

	int index = -1;
	for (int i = 0; i < 20; i++) {
		if (vtable[i] != 探测虚表[i]) {
			index = i;
			break;
		}
	}

	if (index != -1) {
		// 3. 准备拦截函数
		// 使用 lambda (无捕获) 转为函数指针
		auto 拦截器 = [](void* pThis) {
			按钮* btn = (按钮*)pThis;
			::MessageBoxW(NULL, L"哈！你的虚表被我黑掉了！\n这意味着程序里所有这类按钮都被我控制了。", L"骚操作成功", MB_OK);
		};

		// 4. 修改内存保护并覆写全局虚表
		DWORD old;
		if (VirtualProtect(&vtable[index], sizeof(void*), PAGE_EXECUTE_READWRITE, &old)) {
			vtable[index] = (void*)+拦截器; 
			VirtualProtect(&vtable[index], sizeof(void*), old, &old);
		}
	}

	窗口::完毕(模态);
}