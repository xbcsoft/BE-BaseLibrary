﻿#pragma once
#include "../BEWin32UI.h"

struct _窗口3 : 窗口
{
	void 事件_创建完毕();
	void 事件_被销毁();

	void _按钮1_被单击();


#pragma region 组件成员
	struct _选择夹1 :选择夹{
	}选择夹1;

	struct _按钮1 :按钮{
		void 事件_被单击();
	}按钮1;
#pragma endregion
	void 载入(窗口* 父窗 = 0, bool 模态 = 0);
	void 完毕(bool 模态);
}; extern _窗口3 窗口3;
