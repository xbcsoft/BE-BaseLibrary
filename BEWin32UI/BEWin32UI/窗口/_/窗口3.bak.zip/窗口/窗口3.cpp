﻿#include "../BEWin32UI.h"
#include "_启动窗口.h" //窗口3也可以互通_启动窗口

struct _窗口3 : 窗口
{
	void 事件_创建完毕(){

	}
	void 事件_被销毁(){
		_启动窗口.销毁();
	}

	void _按钮1_被单击(){
		//信息框(选择夹1.取子夹标题(选择夹1.现行子夹_));
		选择夹1.背景颜色(颜色::芙红);
	}


#pragma region 组件成员
	struct _选择夹1 :选择夹{
	}选择夹1;

	struct _按钮1 :按钮{
		void 事件_被单击() { 窗口3._按钮1_被单击(); }
	}按钮1;
#pragma endregion
	void 载入(窗口* 父窗 = 0, bool 模态 = 0);
	void 完毕(bool 模态);
} 窗口3;
